CREATE DATABASE base;
use base;
CREATE TABLE table1
(field1 int,
field2 int,
field3 int);
insert into table1 (field1, field2, field3) VALUES (1, 2, 3);
select field1, field2, field3 from table1 where field1 >= 1;
SET SQL_SAFE_UPDATES = 0;
update table1 set field1 = 4, field2 = 5, field3 = 6;
select field1, field2, field3 from table1;