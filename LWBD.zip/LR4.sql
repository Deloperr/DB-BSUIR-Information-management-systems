CREATE TABLE Client (
    Client_ID SERIAL PRIMARY KEY,
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50) NOT NULL,
    Phone VARCHAR(15),
    Email VARCHAR(100)
);

CREATE TABLE Car (
    Car_ID SERIAL PRIMARY KEY,
    Model VARCHAR(50) NOT NULL,
    Year_Of_Manufacture INT CHECK (Year_Of_Manufacture > 1885), -- Year cannot be earlier than 1886
    VIN VARCHAR(17) UNIQUE NOT NULL,
    Client_ID INT REFERENCES Client(Client_ID) ON DELETE CASCADE
);

CREATE TABLE Maintenance (
    Maintenance_ID SERIAL PRIMARY KEY,
    Date DATE NOT NULL,
    Maintenance_Type VARCHAR(50),
    Car_ID INT REFERENCES Car(Car_ID) ON DELETE CASCADE
);

CREATE TABLE Spare_Part (
    Spare_Part_ID SERIAL PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Price DECIMAL(10, 2) NOT NULL,
    Quantity_In_Stock INT NOT NULL
);

CREATE TABLE Service (
    Service_ID SERIAL PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Price DECIMAL(10, 2) NOT NULL
);

CREATE TABLE Invoice (
    Invoice_ID SERIAL PRIMARY KEY,
    Date DATE NOT NULL,
    Amount DECIMAL(10, 2) NOT NULL,
    Client_ID INT REFERENCES Client(Client_ID) ON DELETE CASCADE,
    Maintenance_ID INT REFERENCES Maintenance(Maintenance_ID) ON DELETE CASCADE
);

CREATE TABLE Mechanic (
    Mechanic_ID SERIAL PRIMARY KEY,
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50) NOT NULL,
    Specialty VARCHAR(50)
);

CREATE TABLE Work (
    Work_ID SERIAL PRIMARY KEY,
    Description TEXT NOT NULL,
    Service_ID INT REFERENCES Service(Service_ID) ON DELETE CASCADE,
    Maintenance_ID INT REFERENCES Maintenance(Maintenance_ID) ON DELETE CASCADE,
    Mechanic_ID INT REFERENCES Mechanic(Mechanic_ID) ON DELETE CASCADE
);

CREATE TABLE Supplier (
    Supplier_ID SERIAL PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Contact_Person VARCHAR(50),
    Phone VARCHAR(15)
);

CREATE TABLE Orders (
    Order_ID SERIAL PRIMARY KEY,
    Date DATE NOT NULL,
    Spare_Part_ID INT REFERENCES Spare_Part(Spare_Part_ID) ON DELETE CASCADE,
    Supplier_ID INT REFERENCES Supplier(Supplier_ID) ON DELETE CASCADE,
    Quantity INT NOT NULL
);

CREATE TABLE Payment (
    Payment_ID SERIAL PRIMARY KEY,
    Date DATE NOT NULL,
    Amount DECIMAL(10, 2) NOT NULL,
    Invoice_ID INT REFERENCES Invoice(Invoice_ID) ON DELETE CASCADE
);

CREATE TABLE Warehouse (
    Warehouse_ID SERIAL PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Location VARCHAR(100)
);

CREATE TABLE Appointment (
    Appointment_ID SERIAL PRIMARY KEY,
    Date DATE NOT NULL,
    Time TIME NOT NULL,
    Client_ID INT REFERENCES Client(Client_ID) ON DELETE CASCADE,
    Car_ID INT REFERENCES Car(Car_ID) ON DELETE CASCADE
);

CREATE TABLE Maintenance_History (
    History_ID SERIAL PRIMARY KEY,
    Date DATE NOT NULL,
    Description TEXT NOT NULL,
    Maintenance_ID INT REFERENCES Maintenance(Maintenance_ID) ON DELETE CASCADE
);

CREATE TABLE Review (
    Review_ID SERIAL PRIMARY KEY,
    Rating INT CHECK (Rating >= 1 AND Rating <= 5),
    Comment TEXT,
    Client_ID INT REFERENCES Client(Client_ID) ON DELETE CASCADE
);
