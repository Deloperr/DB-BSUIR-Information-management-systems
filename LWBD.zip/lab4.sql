CREATE DATABASE L3;
USE L3;
CREATE TABLE `manuf` (
`IDM` int PRIMARY KEY,  
`name` varchar(20),  
`city` varchar(20));
INSERT INTO `manuf` VALUES 
(1,'Intel','Santa Clara'),
(2,'AMD','Santa Clara'),
(3,'WD','San Jose'),
(4,'seagete','Cupertino'),
(5,'Asus','Taipei'),
(6,'Dell','Round Rock');
CREATE TABLE `cpu` (
`IDC` int PRIMARY KEY ,
`IDM` int,
`Name` varchar(20),
`clock` decimal(5,2));
INSERT INTO `cpu` VALUES 
(1,1,'i5',3.20),
(2,1,'i7',4.70),
(3,2,'Ryzen 5',3.20),
(4,2,'Ryzen 7',4.70),
(5,NULL,'Power9',3.50);
CREATE TABLE `hdisk` (
`IDD` int PRIMARY KEY,
`IDM` int,
`Name` varchar(20),
`type` varchar(20),
`size` int);
INSERT INTO `hdisk` VALUES 
(1,3,'Green','hdd',1000),
(2,3,'Black','ssd',256),
(3,1,'6000p','ssd',256),
(4,1,'Optane','ssd',16);
CREATE TABLE `nb` (
`IDN` int PRIMARY KEY,
`IDM` int,
`Name` varchar(20),
`IDC` int,
`IDD` int);
INSERT INTO `nb` VALUES 
(1,5,'Zenbook',2,2),
(2,6,'XPS',2,2),
(3,9,'Pavilion',2,2),
(4,6,'Inspiron',3,4),
(5,5,'Vivobook',1,1),
(6,6,'XPS',4,1);
-- 3	Соединить таблицы Manuf и CPU через запятую без условия (Неявное соединение таблиц)
-- Решение:
SELECT *
FROM manuf, cpu;

-- 4	Соединить таблицы Manuf и CPU через запятую с условием (Неявное соединение таблиц)
-- Решение:
SELECT *
FROM manuf, cpu
WHERE manuf.IDM = cpu.IDM;

-- 5	Соединить таблицы Manuf и CPU используя  INNER JOIN
-- Решение:
SELECT *
FROM manuf
INNER JOIN cpu ON manuf.IDM = cpu.IDM;

-- 6	Соединить таблицы Manuf и CPU используя  LEFT JOIN
-- Решение:
 SELECT *
FROM manuf
LEFT JOIN cpu ON manuf.IDM = cpu.IDM;

-- 7	Соединить таблицы Manuf и CPU используя  RIGHT JOIN
-- Решение:
SELECT *
FROM manuf
RIGHT JOIN cpu ON manuf.IDM = cpu.IDM;

-- 8	Соединить таблицы Manuf и CPU используя  CROSS  JOIN
-- Решение:
SELECT *
FROM manuf
CROSS JOIN cpu;

-- 8а Провести анализ  результатов соединения таблиц 3-8 заданий?
-- не буду
-- 9	Вывести название фирмы и модель диска. Список не должен содержать пустых значений (NULL)
-- Решение:
SELECT manuf.name AS Firm_Name, hdisk.name AS Disk_Model
FROM manuf
JOIN hdisk ON manuf.IDM = hdisk.IDM
WHERE hdisk.name IS NOT NULL;

-- 10	Вывести модель процессора и, если есть информация в БД, название фирмы
-- Решение:
SELECT cpu.Name AS Processor_Model, manuf.Name AS Firm_Name
FROM cpu
LEFT JOIN manuf ON cpu.IDM = manuf.IDM;

-- 11	Вывести модели ноутбуков, у которых нет информации в базе данных о фирме изготовителе
-- Решение:
SELECT nb.Name AS Laptop_Model
FROM nb
WHERE nb.IDM IS NULL;

-- 12	Вывести модель ноутбука и название производителя ноутбука, название модели процессора, название модели диска
-- Решение:
SELECT nb.Name AS Laptop_Model, manuf.Name AS Manufacturer, cpu.Name AS Processor_Model, hdisk.Name AS Disk_Model
FROM nb
JOIN manuf ON nb.IDM = manuf.IDM
JOIN cpu ON nb.IDC = cpu.IDC
JOIN hdisk ON nb.IDD = hdisk.IDD;

-- 13	Вывести модель ноутбука, фирму производителя ноутбука, а также для этой модели:	модель и название фирмы производителя процессора, модель и название фирмы производителя диска
-- Решение:
SELECT nb.Name AS Laptop_Model, manuf.Name AS Manufacturer,
       cpu.Name AS Processor_Model, manuf_cpu.Name AS Processor_Manufacturer,
       hdisk.Name AS Disk_Model, manuf_hdisk.Name AS Disk_Manufacturer
FROM nb
JOIN manuf ON nb.IDM = manuf.IDM
JOIN cpu ON nb.IDC = cpu.IDC
JOIN manuf manuf_cpu ON cpu.IDM = manuf_cpu.IDM
JOIN hdisk ON nb.IDD = hdisk.IDD
JOIN manuf manuf_hdisk ON hdisk.IDM = manuf_hdisk.IDM;

-- 14	Вывести абсолютно все названия фирм в первом поле и все моделей процессоров во втором
-- Решение:
SELECT nb.Name AS Laptop_Model, manuf.Name AS Manufacturer,
       cpu.Name AS Processor_Model, manuf_cpu.Name AS Processor_Manufacturer,
       hdisk.Name AS Disk_Model, manuf_hdisk.Name AS Disk_Manufacturer
FROM nb
JOIN manuf ON nb.IDM = manuf.IDM
JOIN cpu ON nb.IDC = cpu.IDC
JOIN manuf manuf_cpu ON cpu.IDM = manuf_cpu.IDM
JOIN hdisk ON nb.IDD = hdisk.IDD
JOIN manuf manuf_hdisk ON hdisk.IDM = manuf_hdisk.IDM;

-- 15	Вывести название фирмы, которая производит несколько типов товаров
-- Решение:
SELECT manuf.Name AS Firm_Name
FROM manuf
JOIN cpu ON manuf.IDM = cpu.IDM
GROUP BY manuf.Name
HAVING COUNT(DISTINCT cpu.IDC) > 1
UNION
SELECT manuf.Name AS Firm_Name
FROM manuf
JOIN hdisk ON manuf.IDM = hdisk.IDM
GROUP BY manuf.Name
HAVING COUNT(DISTINCT hdisk.IDD) > 1;
