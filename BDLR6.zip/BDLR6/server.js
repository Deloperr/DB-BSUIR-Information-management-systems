require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const path = require('path');

const app = express();

// Загрузка конфигурации из .env
const dbConfig = {
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
};

const pool = new Pool(dbConfig);

// Проверка подключения к БД
pool.connect((err) => {
  if (err) {
    console.error('Ошибка подключения к PostgreSQL:', err.stack);
  } else {
    console.log('Успешное подключение к PostgreSQL');
  }
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Маршруты
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.post('/submit', async (req, res) => {
  const { name, email, phone, availability, skills, comments } = req.body;
  
  try {
    await pool.query(
      `INSERT INTO participants 
       (name, email, phone, availability, skills, comments) 
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [name, email, phone, availability, skills, comments]
    );
    
    res.sendFile(path.join(__dirname, 'public', 'success.html'));
  } catch (err) {
    console.error('Ошибка при сохранении:', err);
    res.status(500).sendFile(path.join(__dirname, 'public', 'error.html'));
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Сервер запущен на http://localhost:${PORT}`);
});